import React, { useState } from 'react';
import axios from 'axios';
import logo from '../assets/free_hit_logo.png';
import BookingForm from "./BookingForm";
import BookingList from "./BookingList";
const BookingFormMaster = () => {
    const [showForm, setShowForm] = useState(false);
    const [isEdit,setIsEdit] = useState(false);
    const [editData,setEditData] = useState({});
    const [showFilter,setShowFilter] = useState(false);

    const showEditNewForm = () => {
        setIsEdit(false);
        setEditData({});
        setShowForm(!showForm);
    }

    return (
        <>
            {showForm && <BookingForm
                setShowForm={setShowForm}
                showForm={showForm}
                isEdit={isEdit}
                editData={editData}
            />}
            {!showForm && (
                <div className="container">
                    <div className="title">
                        <div className="logo_inner_div">
                            <img className="logo_img" src={logo} alt="Logo"/> Free Hit List
                        </div>
                        <div className="buttons">
                            <button className="add_new_button act" onClick={() => showEditNewForm()}>Add New</button>
                            <button className="add_new_button act" onClick={() => setShowFilter(!showFilter)}>{!showFilter ? 'Show' : 'Hide'} Filter</button>
                        </div>
                    </div>
                    <BookingList
                        setIsEdit={setIsEdit}
                        setEditData={setEditData}
                        setShowForm={setShowForm}
                        showForm={showForm}
                        showFilter={showFilter}
                        setShowFilter={setShowFilter}
                    />
                </div>
            )}
        </>
    );
}

export default BookingFormMaster;