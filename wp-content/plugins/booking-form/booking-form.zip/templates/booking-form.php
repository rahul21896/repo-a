<?php
/* Template Name: Booking Form */

get_header();
?>
<div id="booking-form">
    <h2>Loading...</h2>
</div>

<?php
get_footer();